package org.example.onu_mujeres_crud.servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.example.onu_mujeres_crud.beans.Usuario;
import org.example.onu_mujeres_crud.beans.Zona;
import org.example.onu_mujeres_crud.beans.Distrito;
import org.example.onu_mujeres_crud.beans.Encuesta;
import org.example.onu_mujeres_crud.daos.CoordinadorDao;
import org.example.onu_mujeres_crud.daos.ZonaDAO;
import org.example.onu_mujeres_crud.daos.EncuestaDAO;



import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "CoordinadorServlet", value = "/CoordinadorServlet")
public class CoordinadorServlet extends HttpServlet {
    ZonaDAO zonaDAO = new ZonaDAO();
    CoordinadorDao coordinadorDAO = new CoordinadorDao();
    EncuestaDAO encuestaDAO = new EncuestaDAO();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action") == null ? "menu" : request.getParameter("action");

        RequestDispatcher view;

        switch (action) {
            case "lista":
                ArrayList<Usuario> listaEncuestadores = coordinadorDAO.listarEncuestadores();
                ArrayList<Zona> listaZonas = zonaDAO.obtenerListaZonas();

                request.setAttribute("listaEncuestadores", listaEncuestadores);
                request.setAttribute("listaZonas", listaZonas);

                view = request.getRequestDispatcher("Coordinador/VistaListaEncuestador.jsp");
                view.forward(request, response);
                break;

            case "ver":
                int idVer = Integer.parseInt(request.getParameter("id"));
                Usuario encuestador = coordinadorDAO.obtenerEncuestadorPorId(idVer);
                request.setAttribute("encuestador", encuestador);

                // Pasar filtros si existen
                String zonaIdFiltro = request.getParameter("zonaId");
                String distritoIdFiltro = request.getParameter("distritoId");

                request.setAttribute("zonaIdFiltro", zonaIdFiltro);
                request.setAttribute("distritoIdFiltro", distritoIdFiltro);

                view = request.getRequestDispatcher("Coordinador/verEncuestador.jsp");
                view.forward(request, response);
                break;
            // actualiza estado (tiene ir en doPost)
            case "estado":
                int idEstado = Integer.parseInt(request.getParameter("id"));
                String estadoActual = request.getParameter("estado");
                String nuevoEstado = estadoActual.equals("activo") ? "inactivo" : "activo";
                coordinadorDAO.cambiarEstadoEncuestador(idEstado, nuevoEstado);
                String zonaIdParam = request.getParameter("zonaId");
                String distritoIdParam = request.getParameter("distritoId");

                String redirectUrl = "CoordinadorServlet?action=filtrar";

                if (zonaIdParam != null && !zonaIdParam.isEmpty()) {
                    redirectUrl += "&zonaId=" + zonaIdParam;
                }

                if (distritoIdParam != null && !distritoIdParam.isEmpty()) {
                    redirectUrl += "&distritoId=" + distritoIdParam;
                }

                response.sendRedirect(redirectUrl);

                break;

            // Prepara los parametros que apareceran en la vista "asignarFormulario"
            case "asignarFormulario":
                int idEncuestador = Integer.parseInt(request.getParameter("id"));
                request.setAttribute("idEncuestador", idEncuestador);

                String carpetaSeleccionada = request.getParameter("carpeta");
                request.setAttribute("carpeta", carpetaSeleccionada);

                // Lista de carpetas
                ArrayList<String> listaCarpetas = encuestaDAO.obtenerCarpetasDisponibles();
                request.setAttribute("listaCarpetas", listaCarpetas);

                // Lista de encuestas de esa carpeta (si está seleccionada)
                ArrayList<Encuesta> listaEncuestas = new ArrayList<>();
                if (carpetaSeleccionada != null && !carpetaSeleccionada.isEmpty()) {
                    listaEncuestas = encuestaDAO.obtenerEncuestasPorCarpeta(carpetaSeleccionada);
                }
                request.setAttribute("listaEncuestas", listaEncuestas);

                // Mantener filtros anteriores si se volviera desde otra vista
                request.setAttribute("zonaIdFiltro", request.getParameter("zonaId"));
                request.setAttribute("distritoIdFiltro", request.getParameter("distritoId"));

                view = request.getRequestDispatcher("Coordinador/asignarFormulario.jsp");
                view.forward(request, response);
                break;


            // Obtener parámetros del filtro en la vista ListaVistaEncuestador.jsp

            case "filtrar":
                String zonaIdStr = request.getParameter("zonaId");
                String distritoIdStr = request.getParameter("distritoId");

                ArrayList<Zona> listaZonasFiltro = zonaDAO.obtenerListaZonas();
                request.setAttribute("listaZonas", listaZonasFiltro);

                if (zonaIdStr == null || zonaIdStr.isEmpty()) {
                    // Mostrar todos los encuestadores si no se elige zona
                    ArrayList<Usuario> listaEncuestadores1 = coordinadorDAO.listarEncuestadores();
                    request.setAttribute("listaEncuestadores", listaEncuestadores1);
                    request.setAttribute("listaDistritos", new ArrayList<>()); // lista vacía para ocultar
                } else {
                    // Zona seleccionada
                    int zonaId = Integer.parseInt(zonaIdStr);
                    request.setAttribute("zonaSeleccionada", zonaId);

                    // Cargar distritos asociados a la zona
                    ArrayList<Distrito> listaDistritos = coordinadorDAO.listarDistritosPorZona(zonaId);
                    request.setAttribute("listaDistritos", listaDistritos);

                    if (distritoIdStr == null || distritoIdStr.isEmpty()) {
                        // Solo zona seleccionada
                        ArrayList<Usuario> listaFiltrada = coordinadorDAO.listarEncuestadoresPorZona(zonaId);
                        request.setAttribute("listaEncuestadores", listaFiltrada);
                    } else {
                        // Zona + distrito seleccionados
                        int distritoId = Integer.parseInt(distritoIdStr);
                        ArrayList<Usuario> listaFiltrada = coordinadorDAO.obtenerTodosEncuestadoresPorZonaYDistrito(zonaId, distritoId);
                        request.setAttribute("distritoSeleccionado", distritoId);
                        request.setAttribute("listaEncuestadores", listaFiltrada);
                    }
                }

                view = request.getRequestDispatcher("Coordinador/VistaListaEncuestador.jsp");
                view.forward(request, response);
                break;


            // ----Encuestas -----

            // Ver
            case "listarEncuestas":
                carpetaSeleccionada = request.getParameter("carpeta");
                ArrayList<Encuesta> encuestas;
                ArrayList<String> carpetas = encuestaDAO.obtenerCarpetasDisponibles();

                if (carpetaSeleccionada != null && !carpetaSeleccionada.isEmpty()) {
                    encuestas = encuestaDAO.obtenerEncuestasPorCarpeta(carpetaSeleccionada);
                } else {
                    encuestas = encuestaDAO.obtenerEncuestasPorCarpeta(""); // Muestra todas si no se filtra
                }

                request.setAttribute("listaEncuestas", encuestas);
                request.setAttribute("listaCarpetas", carpetas);
                request.setAttribute("carpetaSeleccionada", carpetaSeleccionada);

                view = request.getRequestDispatcher("Coordinador/VistaListaEncuestas.jsp");
                view.forward(request, response);
                break;

            // Actualizar estado de encuesta (tiene que ir en doPost)
            case "cambiarEstadoEncuesta":
                int encuestaId = Integer.parseInt(request.getParameter("id"));
                String estadoActualEncuesta = request.getParameter("estado"); // "activo" o "inactivo"
                String nuevoEstadoEncuesta = estadoActualEncuesta.equals("activo") ? "inactivo" : "activo";

                encuestaDAO.actualizarEstadoEncuesta(encuestaId, nuevoEstadoEncuesta);

                // Redireccionar de vuelta a la lista de encuestas
                String carpetaParam = request.getParameter("carpeta");
                redirectUrl = "CoordinadorServlet?action=listarEncuestas&mensaje=estadoActualizado";
                if (carpetaParam != null && !carpetaParam.isEmpty()) {
                    redirectUrl += "&carpeta=" + carpetaParam;
                }
                response.sendRedirect(redirectUrl);


                break;

            // Ver perfil de encuesta
            case "verEncuesta":
                int idEncuesta = Integer.parseInt(request.getParameter("id"));
                Encuesta encuesta = encuestaDAO.obtenerEncuestaPorId(idEncuesta);
                request.setAttribute("encuesta", encuesta);
                view = request.getRequestDispatcher("Coordinador/verEncuesta.jsp");
                view.forward(request, response);
                break;

            // filtrar zona y distrito para asignar formulario a encuestador

            case "filtrarAsignar":

                String zonaFiltrarIdStr = request.getParameter("zonaId");
                String distritoFiltrarIdStr = request.getParameter("distritoId");
                String encuestaIdStr = request.getParameter("encuestaId");
                carpetaParam = request.getParameter("carpeta");
                String nombreEncuesta = request.getParameter("nombreEncuesta");

                if (carpetaParam != null) request.setAttribute("carpetaSeleccionada", carpetaParam);
                if (nombreEncuesta != null) request.setAttribute("nombreEncuesta", nombreEncuesta);

                ArrayList<Zona> zonas = zonaDAO.obtenerListaZonas();
                request.setAttribute("listaZonas", zonas);

                // Guardar el ID de la encuesta seleccionada para usarlo en el JSP
                if (encuestaIdStr != null && !encuestaIdStr.isEmpty()) {
                    request.setAttribute("encuestaId", encuestaIdStr);
                }


                if (zonaFiltrarIdStr != null && !zonaFiltrarIdStr.isEmpty()) {
                    int zonaId = Integer.parseInt(zonaFiltrarIdStr);
                    ArrayList<Distrito> distritos = coordinadorDAO.listarDistritosPorZona(zonaId);
                    request.setAttribute("listaDistritos", distritos);
                    request.setAttribute("zonaSeleccionada", zonaId);

                    if (distritoFiltrarIdStr != null && !distritoFiltrarIdStr.isEmpty()) {
                        int distritoId = Integer.parseInt(distritoFiltrarIdStr);
                        ArrayList<Usuario> encuestadoresFiltrados = coordinadorDAO.obtenerEncuestadoresPorZonaYDistrito(zonaId, distritoId);
                        request.setAttribute("listaEncuestadores", encuestadoresFiltrados);
                        request.setAttribute("distritoSeleccionado", distritoId);
                    }
                }

                view = request.getRequestDispatcher("Coordinador/asignarFormulario2.jsp");
                view.forward(request, response);
                break;


            // --MENU--

            case "menu":
                view = request.getRequestDispatcher("Coordinador/CoordinadorMenu.jsp");
                view.forward(request, response);
                break;


            default:
                response.sendRedirect("CoordinadorServlet?action=lista");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("guardarAsignacion".equals(action)) {
            int encuestadorId = Integer.parseInt(request.getParameter("idEncuestador"));
            String nombreEncuesta = request.getParameter("nombreEncuesta");
            String carpeta = request.getParameter("carpeta");

            // En este ejemplo el coordinador que asigna es el ID 1 (en un caso real se obtiene del session)
            int coordinadorId = 1;

            coordinadorDAO.asignarEncuesta(nombreEncuesta, carpeta, encuestadorId, coordinadorId);

            // Revisar el origen de la solicitud
            String origen = request.getParameter("origen");

            if ("vistaEncuestadores".equals(origen)) {
                // Recuperar filtros
                String zonaId = request.getParameter("zonaId");
                String distritoId = request.getParameter("distritoId");

                String redirectUrl = "CoordinadorServlet?action=filtrar";
                if (zonaId != null && !zonaId.isEmpty()) {
                    redirectUrl += "&zonaId=" + zonaId;
                }
                if (distritoId != null && !distritoId.isEmpty()) {
                    redirectUrl += "&distritoId=" + distritoId;
                }
                redirectUrl += "&mensaje=asignacionExitosa";

                response.sendRedirect(redirectUrl);

            } else {
                // Por defecto redirige a encuestas (lógica anterior intacta)
                String redirectUrl = "CoordinadorServlet?action=listarEncuestas";
                if (carpeta != null && !carpeta.isEmpty()) {
                    redirectUrl += "&carpeta=" + carpeta + "&mensaje=asignacionExitosa";
                }
                response.sendRedirect(redirectUrl);
            }
        }
        // Asignacion de encuestas desde la secion "encuestas"
        if ("guardarAsignacionDesdeEncuestas".equals(action)) {
            int encuestadorId = Integer.parseInt(request.getParameter("idEncuestador"));
            int encuestaId = Integer.parseInt(request.getParameter("encuestaId"));
            int coordinadorId = 1;

            coordinadorDAO.asignarEncuestaPorId(encuestaId, encuestadorId, coordinadorId);

            String carpeta = request.getParameter("carpeta");
            String redirectUrl = "CoordinadorServlet?action=listarEncuestas&mensaje=asignacionExitosa";
            if (carpeta != null && !carpeta.isEmpty()) {
                redirectUrl += "&carpeta=" + carpeta;
            }
            response.sendRedirect(redirectUrl);
        }


    }


}

//package org.example.onu_mujeres_crud.servlet;
//
//import jakarta.servlet.*;
//import jakarta.servlet.http.*;
//import jakarta.servlet.annotation.*;
//import org.example.onu_mujeres_crud.beans.Usuario;
//import org.example.onu_mujeres_crud.beans.Zona;
//import org.example.onu_mujeres_crud.beans.Distrito;
//import org.example.onu_mujeres_crud.beans.Encuesta;
//import org.example.onu_mujeres_crud.daos.CoordinadorDao;
//import org.example.onu_mujeres_crud.daos.ZonaDAO;
//import org.example.onu_mujeres_crud.daos.EncuestaDAO;
//
//
//
//import java.io.IOException;
//import java.util.ArrayList;
//
//@WebServlet(name = "CoordinadorServlet", value = "/CoordinadorServlet")
//public class CoordinadorServlet extends HttpServlet {
//    ZonaDAO zonaDAO = new ZonaDAO();
//    CoordinadorDao coordinadorDAO = new CoordinadorDao();
//    EncuestaDAO encuestaDAO = new EncuestaDAO();
//
//
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        String action = request.getParameter("action") == null ? "menu" : request.getParameter("action");
//
//        RequestDispatcher view;
//
//        switch (action) {
//            case "lista":
//                ArrayList<Usuario> listaEncuestadores = coordinadorDAO.listarEncuestadores();
//                ArrayList<Zona> listaZonas = zonaDAO.obtenerListaZonas();
//
//                request.setAttribute("listaEncuestadores", listaEncuestadores);
//                request.setAttribute("listaZonas", listaZonas);
//
//                view = request.getRequestDispatcher("Coordinador/VistaListaEncuestador.jsp");
//                view.forward(request, response);
//                break;
//
//
//            case "ver":
//                int idVer = Integer.parseInt(request.getParameter("id"));
//                Usuario encuestador = coordinadorDAO.obtenerEncuestadorPorId(idVer);
//                request.setAttribute("encuestador", encuestador);
//
//                // Pasar filtros si existen
//                String zonaIdFiltro = request.getParameter("zonaId");
//                String distritoIdFiltro = request.getParameter("distritoId");
//
//                request.setAttribute("zonaIdFiltro", zonaIdFiltro);
//                request.setAttribute("distritoIdFiltro", distritoIdFiltro);
//
//                view = request.getRequestDispatcher("Coordinador/verEncuestador.jsp");
//                view.forward(request, response);
//                break;
//
//            case "estado":
//                int idEstado = Integer.parseInt(request.getParameter("id"));
//                String estadoActual = request.getParameter("estado");
//                String nuevoEstado = estadoActual.equals("activo") ? "inactivo" : "activo";
//                coordinadorDAO.cambiarEstadoEncuestador(idEstado, nuevoEstado);
//                String zonaIdParam = request.getParameter("zonaId");
//                String distritoIdParam = request.getParameter("distritoId");
//
//                String redirectUrl = "CoordinadorServlet?action=filtrar";
//
//                if (zonaIdParam != null && !zonaIdParam.isEmpty()) {
//                    redirectUrl += "&zonaId=" + zonaIdParam;
//                }
//
//                if (distritoIdParam != null && !distritoIdParam.isEmpty()) {
//                    redirectUrl += "&distritoId=" + distritoIdParam;
//                }
//
//                response.sendRedirect(redirectUrl);
//
//                break;
//
//            case "asignarFormulario":
//                int idEncuestador = Integer.parseInt(request.getParameter("id"));
//                request.setAttribute("idEncuestador", idEncuestador);
//
//                String carpetaSeleccionada = request.getParameter("carpeta");
//                request.setAttribute("carpeta", carpetaSeleccionada);
//
//                // Lista de carpetas
//                ArrayList<String> listaCarpetas = encuestaDAO.obtenerCarpetasDisponibles();
//                request.setAttribute("listaCarpetas", listaCarpetas);
//
//                // Lista de encuestas de esa carpeta (si está seleccionada)
//                ArrayList<Encuesta> listaEncuestas = new ArrayList<>();
//                if (carpetaSeleccionada != null && !carpetaSeleccionada.isEmpty()) {
//                    listaEncuestas = encuestaDAO.obtenerEncuestasPorCarpeta(carpetaSeleccionada);
//                }
//                request.setAttribute("listaEncuestas", listaEncuestas);
//
//                // Mantener filtros anteriores si se volviera desde otra vista
//                request.setAttribute("zonaIdFiltro", request.getParameter("zonaId"));
//                request.setAttribute("distritoIdFiltro", request.getParameter("distritoId"));
//
//                view = request.getRequestDispatcher("Coordinador/asignarFormulario.jsp");
//                view.forward(request, response);
//                break;
//
//
//            // Obtener parámetros del filtro en la vista ListaVistaEncuestador.jsp
//
//            case "filtrar":
//                String zonaIdStr = request.getParameter("zonaId");
//                String distritoIdStr = request.getParameter("distritoId");
//
//                ArrayList<Zona> listaZonasFiltro = zonaDAO.obtenerListaZonas();
//                request.setAttribute("listaZonas", listaZonasFiltro);
//
//                if (zonaIdStr == null || zonaIdStr.isEmpty()) {
//                    // Mostrar todos los encuestadores si no se elige zona
//                    ArrayList<Usuario> listaEncuestadores1 = coordinadorDAO.listarEncuestadores();
//                    request.setAttribute("listaEncuestadores", listaEncuestadores1);
//                    request.setAttribute("listaDistritos", new ArrayList<>()); // lista vacía para ocultar
//                } else {
//                    // Zona seleccionada
//                    int zonaId = Integer.parseInt(zonaIdStr);
//                    request.setAttribute("zonaSeleccionada", zonaId);
//
//                    // Cargar distritos asociados a la zona
//                    ArrayList<Distrito> listaDistritos = coordinadorDAO.listarDistritosPorZona(zonaId);
//                    request.setAttribute("listaDistritos", listaDistritos);
//
//                    if (distritoIdStr == null || distritoIdStr.isEmpty()) {
//                        // Solo zona seleccionada
//                        ArrayList<Usuario> listaFiltrada = coordinadorDAO.listarEncuestadoresPorZona(zonaId);
//                        request.setAttribute("listaEncuestadores", listaFiltrada);
//                    } else {
//                        // Zona + distrito seleccionados
//                        int distritoId = Integer.parseInt(distritoIdStr);
//                        ArrayList<Usuario> listaFiltrada = coordinadorDAO.obtenerTodosEncuestadoresPorZonaYDistrito(zonaId, distritoId);
//                        request.setAttribute("distritoSeleccionado", distritoId);
//                        request.setAttribute("listaEncuestadores", listaFiltrada);
//                    }
//                }
//
//                view = request.getRequestDispatcher("Coordinador/VistaListaEncuestador.jsp");
//                view.forward(request, response);
//                break;
//
//
//            // ----Encuestas -----
//
//            // Ver
//            case "listarEncuestas":
//                carpetaSeleccionada = request.getParameter("carpeta");
//                ArrayList<Encuesta> encuestas;
//                ArrayList<String> carpetas = encuestaDAO.obtenerCarpetasDisponibles();
//
//                if (carpetaSeleccionada != null && !carpetaSeleccionada.isEmpty()) {
//                    encuestas = encuestaDAO.obtenerEncuestasPorCarpeta(carpetaSeleccionada);
//                } else {
//                    encuestas = encuestaDAO.obtenerEncuestasPorCarpeta(""); // Muestra todas si no se filtra
//                }
//
//                request.setAttribute("listaEncuestas", encuestas);
//                request.setAttribute("listaCarpetas", carpetas);
//                request.setAttribute("carpetaSeleccionada", carpetaSeleccionada);
//
//                view = request.getRequestDispatcher("Coordinador/VistaListaEncuestas.jsp");
//                view.forward(request, response);
//                break;
//
//            // Actualizar estado
//            case "cambiarEstadoEncuesta":
//                int encuestaId = Integer.parseInt(request.getParameter("id"));
//                String estadoActualEncuesta = request.getParameter("estado"); // "activo" o "inactivo"
//                String nuevoEstadoEncuesta = estadoActualEncuesta.equals("activo") ? "inactivo" : "activo";
//
//                encuestaDAO.actualizarEstadoEncuesta(encuestaId, nuevoEstadoEncuesta);
//
//                // Redireccionar de vuelta a la lista de encuestas
//                String carpetaParam = request.getParameter("carpeta");
//                redirectUrl = "CoordinadorServlet?action=listarEncuestas&mensaje=estadoActualizado";
//                if (carpetaParam != null && !carpetaParam.isEmpty()) {
//                    redirectUrl += "&carpeta=" + carpetaParam;
//                }
//                response.sendRedirect(redirectUrl);
//
//
//                break;
//
//            // Ver perfil de encuesta
//            case "verEncuesta":
//                int idEncuesta = Integer.parseInt(request.getParameter("id"));
//                Encuesta encuesta = encuestaDAO.obtenerEncuestaPorId(idEncuesta);
//                request.setAttribute("encuesta", encuesta);
//                view = request.getRequestDispatcher("Coordinador/verEncuesta.jsp");
//                view.forward(request, response);
//                break;
//
//            // filtrar zona y distrito para asignar formulario a encuestador
//
//            case "filtrarAsignar":
//
//                String zonaFiltrarIdStr = request.getParameter("zonaId");
//                String distritoFiltrarIdStr = request.getParameter("distritoId");
//                String encuestaIdStr = request.getParameter("encuestaId");
//                carpetaParam = request.getParameter("carpeta");
//                String nombreEncuesta = request.getParameter("nombreEncuesta");
//
//                if (carpetaParam != null) request.setAttribute("carpetaSeleccionada", carpetaParam);
//                if (nombreEncuesta != null) request.setAttribute("nombreEncuesta", nombreEncuesta);
//
//                ArrayList<Zona> zonas = zonaDAO.obtenerListaZonas();
//                request.setAttribute("listaZonas", zonas);
//
//                // Guardar el ID de la encuesta seleccionada para usarlo en el JSP
//                if (encuestaIdStr != null && !encuestaIdStr.isEmpty()) {
//                    request.setAttribute("encuestaId", encuestaIdStr);
//                }
//
//
//                if (zonaFiltrarIdStr != null && !zonaFiltrarIdStr.isEmpty()) {
//                    int zonaId = Integer.parseInt(zonaFiltrarIdStr);
//                    ArrayList<Distrito> distritos = coordinadorDAO.listarDistritosPorZona(zonaId);
//                    request.setAttribute("listaDistritos", distritos);
//                    request.setAttribute("zonaSeleccionada", zonaId);
//
//                    if (distritoFiltrarIdStr != null && !distritoFiltrarIdStr.isEmpty()) {
//                        int distritoId = Integer.parseInt(distritoFiltrarIdStr);
//                        ArrayList<Usuario> encuestadoresFiltrados = coordinadorDAO.obtenerEncuestadoresPorZonaYDistrito(zonaId, distritoId);
//                        request.setAttribute("listaEncuestadores", encuestadoresFiltrados);
//                        request.setAttribute("distritoSeleccionado", distritoId);
//                    }
//                }
//
//                view = request.getRequestDispatcher("Coordinador/asignarFormulario2.jsp");
//                view.forward(request, response);
//                break;
//
//
//            // --MENU--
//
//            case "menu":
//                view = request.getRequestDispatcher("Coordinador/CoordinadorMenu.jsp");
//                view.forward(request, response);
//                break;
//
//
//            default:
//                response.sendRedirect("CoordinadorServlet?action=lista");
//        }
//    }
//
//    @Override
//    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        String action = request.getParameter("action");
//
//        if ("guardarAsignacion".equals(action)) {
//            int encuestadorId = Integer.parseInt(request.getParameter("idEncuestador"));
//            String nombreEncuesta = request.getParameter("nombreEncuesta");
//            String carpeta = request.getParameter("carpeta");
//
//            // En este ejemplo el coordinador que asigna es el ID 1 (en un caso real se obtiene del session)
//            int coordinadorId = 1;
//
//            coordinadorDAO.asignarEncuesta(nombreEncuesta, carpeta, encuestadorId, coordinadorId);
//
//            // Revisar el origen de la solicitud
//            String origen = request.getParameter("origen");
//
//            if ("vistaEncuestadores".equals(origen)) {
//                // Recuperar filtros
//                String zonaId = request.getParameter("zonaId");
//                String distritoId = request.getParameter("distritoId");
//
//                String redirectUrl = "CoordinadorServlet?action=filtrar";
//                if (zonaId != null && !zonaId.isEmpty()) {
//                    redirectUrl += "&zonaId=" + zonaId;
//                }
//                if (distritoId != null && !distritoId.isEmpty()) {
//                    redirectUrl += "&distritoId=" + distritoId;
//                }
//                redirectUrl += "&mensaje=asignacionExitosa";
//
//                response.sendRedirect(redirectUrl);
//
//            } else {
//                // Por defecto redirige a encuestas (lógica anterior intacta)
//                String redirectUrl = "CoordinadorServlet?action=listarEncuestas";
//                if (carpeta != null && !carpeta.isEmpty()) {
//                    redirectUrl += "&carpeta=" + carpeta + "&mensaje=asignacionExitosa";
//                }
//                response.sendRedirect(redirectUrl);
//            }
//        }
//    }
//
//
//}

//package org.example.onu_mujeres_crud.servlet;
//
//import jakarta.servlet.*;
//import jakarta.servlet.http.*;
//import jakarta.servlet.annotation.*;
//import org.example.onu_mujeres_crud.beans.Usuario;
//import org.example.onu_mujeres_crud.daos.CoordinadorDao;
//
//import java.io.IOException;
//import java.util.ArrayList;
//
//@WebServlet(name = "CoordinadorServlet", value = "/CoordinadorServlet")
//public class CoordinadorServlet extends HttpServlet {
//    CoordinadorDao coordinadorDAO = new CoordinadorDao();
//
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        String action = request.getParameter("action") == null ? "lista" : request.getParameter("action");
//        RequestDispatcher view;
//
//        switch (action) {
//            case "lista":
//                ArrayList<Usuario> listaEncuestadores = coordinadorDAO.listarEncuestadores();
//                request.setAttribute("listaEncuestadores", listaEncuestadores);
//                view = request.getRequestDispatcher("Coordinador/VistaListaEncuestador.jsp");
//                view.forward(request, response);
//                break;
//
//            case "ver":
//                int idVer = Integer.parseInt(request.getParameter("id"));
//                Usuario encuestador = coordinadorDAO.obtenerEncuestadorPorId(idVer);
//                request.setAttribute("encuestador", encuestador);
//                view = request.getRequestDispatcher("Coordinador/verEncuestador.jsp");
//                view.forward(request, response);
//                break;
//
//            case "estado":
//                int idEstado = Integer.parseInt(request.getParameter("id"));
//                String estadoActual = request.getParameter("estado");
//                String nuevoEstado = estadoActual.equals("activo") ? "inactivo" : "activo";
//                coordinadorDAO.cambiarEstadoEncuestador(idEstado, nuevoEstado);
//                response.sendRedirect("CoordinadorServlet?action=lista");
//                break;
//
//            case "asignarFormulario":
//                int idAsignar = Integer.parseInt(request.getParameter("id"));
//                request.setAttribute("idEncuestador", idAsignar);
//                view = request.getRequestDispatcher("Coordinador/asignarFormulario.jsp");
//                view.forward(request, response);
//                break;
//
//            default:
//                response.sendRedirect("CoordinadorServlet?action=lista");
//        }
//    }
//
//    @Override
//    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        String action = request.getParameter("action");
//
//        if ("guardarAsignacion".equals(action)) {
//            int encuestadorId = Integer.parseInt(request.getParameter("idEncuestador"));
//            String nombreEncuesta = request.getParameter("nombreEncuesta");
//            String carpeta = request.getParameter("carpeta");
//
//            // En este ejemplo el coordinador que asigna es el ID 1 (en un caso real se obtiene del session)
//            int coordinadorId = 1;
//
//            coordinadorDAO.asignarEncuesta(nombreEncuesta, carpeta, encuestadorId, coordinadorId);
//            response.sendRedirect("CoordinadorServlet?action=lista");
//        }
//    }
//}
